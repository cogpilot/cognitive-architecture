# Copilot Collaboration Instructions

This workspace is designed for collaborative study and development of ML, NN, KC (Knowledge Components), MCP, LSP protocols, and formal specifications.

## Workspace Purpose
- Study and analyze ML/NN models and architectures
- Explore Model Context Protocol (MCP) implementations
- Develop Language Server Protocol (LSP) extensions
- Create formal specifications and grammars
- Design custom MCP/LSP protocols optimized for Copilot

## Study Areas
- **ML (Machine Learning)**: Model architectures, training procedures, optimization techniques
- **NN (Neural Networks)**: Network topologies, activation functions, layer designs
- **KC (Knowledge Components)**: Knowledge representation, reasoning systems
- **MCP (Model Context Protocol)**: Context management, model communication
- **LSP (Language Server Protocol)**: Language analysis, code intelligence
- **Formal Specifications**: Grammar definitions, protocol specifications
- **Optimization**: Performance tuning, efficiency improvements

## Development Guidelines
- Focus on understanding core concepts before implementation
- Document all explorations and findings
- Create reusable components and patterns
- Maintain clear separation between study and production code
- Use test-driven development for protocol implementations

## Project Structure
- `/study/`: Research and exploration code
- `/specs/`: Formal specifications and grammars
- `/protocols/`: MCP/LSP protocol implementations
- `/models/`: ML/NN model definitions and experiments
- `/docs/`: Documentation and learning materials
- `/tests/`: Test suites for all components

## Collaboration Notes
- This is a learning environment - experimentation is encouraged
- Document insights and learnings as you progress
- Build incrementally from simple to complex concepts
- Cross-reference implementations across different domains
